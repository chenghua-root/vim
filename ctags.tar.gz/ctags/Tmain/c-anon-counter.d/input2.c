enum {
  G, H,
} a;

struct {
  int I, J;
} b;

union {
  int K, L;
} c;
