===================================
A	tabs	B
===================================
Ths should not be recorded in e-ctags output.
