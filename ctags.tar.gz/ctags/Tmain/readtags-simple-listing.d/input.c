/* u-ctags --sort=yes --fields=* -o output.tags input.c */
int var;
strcut st {
	int m0;
	int m2;
};
char c;
typedef strcut st tst;
