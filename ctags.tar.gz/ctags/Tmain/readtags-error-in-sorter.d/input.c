/* ctags -o output.tags input.c */
void foo (void)
{
}

void bar (void)
{
}

void baz (void)
{
}
