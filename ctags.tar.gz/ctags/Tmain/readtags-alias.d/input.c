/* ctags -o output.tags input.c */
struct point3d {
	int x, y ,z;
};
