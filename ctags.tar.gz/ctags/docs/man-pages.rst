.. _man-pages:

======================================================================
Man pages
======================================================================

.. toctree::
	:maxdepth: 3

	ctags(1) <man/ctags.1.rst>
	ctags-client-tools(7) <man/ctags-client-tools.7.rst>
	ctags-incompatibilities(7) <man/ctags-incompatibilities.7.rst>
	ctags-optlib(7) <man/ctags-optlib.7.rst>
	readtags(1) <man/readtags.1.rst>
	tags(5) <man/tags.5.rst>
